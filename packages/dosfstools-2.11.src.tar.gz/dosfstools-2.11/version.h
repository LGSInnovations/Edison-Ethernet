#ifndef _version_h
#define _version_h

#define	VERSION			"2.11"
#define VERSION_DATE	"12 Mar 2005"

#endif  /* _version_h */

